public class CircuitSym {
    public static final int EOF=-1;
    public static final int LE=0;
    public static final int NE=1;
    public static final int LT=2;
    public static final int EQ=3;
    public static final int GT=4;
    public static final int GE=5;
    public static final int ASSIGN=6;
    public static final int PTOPEN=7;
    public static final int PTCLOSE=8;
    public static final int PGOPEN=9;
    public static final int PGCLOSE=10;
    public static final int SEMI=11;
    public static final int COMMA=12;
    public static final int LITERAL=13;
    public static final int IDENTIFIER=14;
    public static final int error=15;
    public static final int INT=16;
    public static final int FLOAT=17;
    public static final int WHILE=18;
    public static final int ELSE=19;
    public static final int THEN=20;
    public static final int IF=21;

    public static final String [] TOKENS={
        "LE",
        "NE",
            "LT",
            "EQ",
            "GT",
            "GE",
            "ASSIGN",
            "PTOPEN",
            "PTCLOSE",
            "PGOPEN",
            "PGCLOSE",
            "SEMI",
            "COMMA",
            "LITERAL",
            "IDENTIFIER",
            "error",
            "INT",
            "FLOAT",
            "WHILE",
            "ELSE",
            "THEN",
            "IF"

    };


}
