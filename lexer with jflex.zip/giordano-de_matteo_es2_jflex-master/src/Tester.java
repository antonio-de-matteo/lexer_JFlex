import java_cup.runtime.Symbol;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Tester {
    public static void main(String[] args) throws IOException {
        FileReader inFile = new FileReader(args[0]);
        Lexer lexer = new Lexer(inFile);

        Symbol token = lexer.next_token();
        while (token.sym != CircuitSym.EOF) {
            //System.out.println(token.value);
            switch (token.sym) {
                case CircuitSym.LE:
                    System.out.println("(relop ," + token.value + ")");
                    break;
                case CircuitSym.NE:
                    System.out.println("(relop ," + token.value + ")");
                    break;
                case CircuitSym.LT:
                    System.out.println("(relop ," + token.value + ")");
                    break;
                case CircuitSym.EQ:
                    System.out.println("(relop ," + token.value + ")");
                    break;
                case CircuitSym.GT:
                    System.out.println("(relop ," + token.value + ")");
                    break;
                case CircuitSym.GE:
                    System.out.println("(relop ," + token.value + ")");
                    break;
                case CircuitSym.ASSIGN:
                    System.out.println("ASSIGN");
                    break;
                case CircuitSym.PTOPEN:
                    System.out.println("PTOPEN");
                    break;
                case CircuitSym.PTCLOSE:
                    System.out.println("PTCLOSE");
                    break;
                case CircuitSym.PGOPEN:
                    System.out.println("PGOPEN");
                    break;
                case CircuitSym.PGCLOSE:
                    System.out.println("PGCLOSE");
                    break;
                case CircuitSym.SEMI:
                    System.out.println("SEMI");
                    break;
                case CircuitSym.COMMA:
                    System.out.println("COMMA");
                    break;
                case CircuitSym.LITERAL:
                    System.out.println("(NUMBER, "+token.value+")");
                    break;
                case CircuitSym.IDENTIFIER:
                    System.out.println("(ID, "+ token.value+")");
                    break;
                case CircuitSym.INT:
                    System.out.println("INT");
                    break;
                case CircuitSym.FLOAT:
                    System.out.println("FLOAT");
                    break;
                case CircuitSym.WHILE:
                    System.out.println("WHILE");
                    break;
                case CircuitSym.ELSE:
                    System.out.println("ELSE");
                    break;
                case CircuitSym.THEN:
                    System.out.println("THEN");
                    break;
                case CircuitSym.IF:
                    System.out.println("IF");
                    break;

                case CircuitSym.error:
                    System.out.println("(ERROR,"+ token.value+")");
                    break;

            }
            token = lexer.next_token();
        }
    }
}

